# Quick Start Guide - Admin Console Setup

## 🚀 Get Started in 5 Minutes

### Step 1: Set Up Admin User in Database (2 minutes)

Connect to your database and run this SQL command:

```sql
-- Create admin user
INSERT INTO users (username, password, fullName, email, address, role) 
VALUES ('admin', 'admin123', 'Administrator', 'admin@shop.com', 'Admin Office', 'admin');
```

**Or update existing user:**
```sql
UPDATE users SET role = 'admin' WHERE username = 'your_username';
```

### Step 2: Compile the Project (1 minute)

```bash
cd "E-shoppingCart-master"
javac -d build/classes -sourcepath src -cp "lib/*" \
  src/com/eshop/ui/AdminDashboard.java \
  src/com/eshop/ui/MainFrame.java
```

### Step 3: Run the Application (1 minute)

```bash
java -cp build/classes:lib/* com.eshop.ui.LoginFrame
```

### Step 4: Login with Admin Account (1 minute)

1. Enter username: `admin`
2. Enter password: `admin123`
3. Click Login
4. Look for **⚙️ Admin Console** button in top-right corner

### Step 5: Add Your First Product (1 minute)

1. Click **⚙️ Admin Console** button
2. Fill in product details:
   - Name: "Test Product"
   - Description: "My first product"
   - Price: "99.99"
   - Stock: "10"
3. Click **📁 Choose Image File** and select a JPG/PNG image
4. Click **✅ Add Product**
5. See success message!

---

## ✅ Verification

### Test 1: Admin Can See Admin Button
1. Login with admin account
2. ✅ Should see **⚙️ Admin Console** button

### Test 2: Regular User Cannot See Admin Button
1. Login with non-admin account
2. ✅ Should NOT see admin button

### Test 3: Product Added Successfully
1. Run admin console
2. Add a test product with image
3. ✅ Product should appear on main store page with image

---

## 📂 File Changes

### Modified Files:
1. `src/com/eshop/ui/AdminDashboard.java` (Complete rewrite with image upload)
2. `src/com/eshop/ui/MainFrame.java` (Added admin button)

### Compilation Status:
✅ Successfully compiled
✅ No blocking errors
✅ Ready to run

---

## 🎯 Key Features Now Available

| Feature | Status |
|---------|--------|
| Admin Console Access | ✅ Role-based |
| Image Upload | ✅ File chooser with validation |
| Product Management | ✅ Full create functionality |
| Image Storage | ✅ Automatic timestamped names |
| Image Preview | ✅ Shows before adding |
| Input Validation | ✅ Comprehensive checks |
| Error Messages | ✅ User-friendly |
| Backward Compatible | ✅ Works with existing system |

---

## 📋 Checklist

- [ ] Database admin user created or updated
- [ ] Project compiled successfully
- [ ] Application running
- [ ] Logged in with admin account
- [ ] "⚙️ Admin Console" button visible
- [ ] Opened admin console
- [ ] Added test product with image
- [ ] Product appears on main page
- [ ] Image displays correctly

---

## 🆘 Troubleshooting

### Admin Button Not Showing?
```sql
-- Check your role in database
SELECT username, role FROM users WHERE username = 'your_username';

-- Make sure it says 'admin'
UPDATE users SET role = 'admin' WHERE username = 'your_username';
```

### Compilation Failed?
```bash
# Make sure all source files are updated
dir src\com\eshop\ui\AdminDashboard.java
dir src\com\eshop\ui\MainFrame.java

# Try rebuilding
javac -d build/classes -sourcepath src -cp "lib/*" src/com/eshop/ui/*.java
```

### Image Not Uploading?
1. Check image file format (JPG, PNG, GIF)
2. Verify `images` folder exists in project root
3. Check folder write permissions
4. Check error message in application

### Product Not Appearing?
1. Verify product was added to database:
   ```sql
   SELECT * FROM products ORDER BY id DESC LIMIT 1;
   ```
2. Refresh the main page
3. Check if image file exists in `images` folder

---

## 📚 Documentation Files

Three comprehensive guides have been created:

1. **admin-console-guide.md** - Complete feature guide with usage instructions
2. **code-changes-summary.md** - Technical details of all code modifications
3. **database-setup.md** - Database configuration and SQL examples

---

## 🎨 What Changed Visually

### Admin Dashboard Before:
```
Simple form with text fields
Image Name: [________]
No preview
No validation
```

### Admin Dashboard Now:
```
┌─────────────────────────────────────┐
│  Admin Dashboard - Product Management │
│  👤 Admin: Administrator             │
├─────────────────────────────────────┤
│ Product Details                     │
│   Name: [________________]          │
│   Description: [_________________]  │
│   Price: [________]                 │
│   Stock: [________]                 │
├─────────────────────────────────────┤
│ Product Image                       │
│   [Image Preview]    [📁 Browse]    │
│                      Selected: ...  │
├─────────────────────────────────────┤
│   [✅ Add Product]  [🔄 Clear]     │
└─────────────────────────────────────┘
```

---

## 💡 Tips & Tricks

### Tip 1: Create Multiple Admins
```sql
INSERT INTO users (username, password, fullName, email, address, role) 
VALUES ('boss', 'boss123', 'Shop Manager', 'boss@shop.com', 'Address', 'admin');
```

### Tip 2: Organize Product Images
- Images are stored with timestamps: `product_20260301_143050.jpg`
- Check `images` folder to see uploaded images
- Can resize them independently if needed

### Tip 3: Quick Product Verification
```sql
-- See all products with their images
SELECT id, name, price, stock, image FROM products;
```

### Tip 4: Reset Admin Password
```sql
UPDATE users SET password = 'newpassword' WHERE role = 'admin';
```

---

## 🔐 Security Notes

1. **Default credentials** (admin/admin123) should be changed immediately
2. **Use strong passwords** in production
3. **Password hashing** - Implement proper hashing (BCrypt)
4. **Backup regularly** before making changes
5. **Limit admin access** - Only trusted users should be admins

---

## 🎓 Next Steps

After getting the admin console working:

1. **Test thoroughly**: Add multiple products with different images
2. **Verify images**: Check that images display correctly on the main page
3. **Test as regular user**: Ensure regular users don't see admin features
4. **Database backup**: Backup your database after adding test data
5. **Deploy**: Move to production when ready

---

## 📞 Need Help?

**Check these files for more information:**
- `admin-console-guide.md` - Complete user guide
- `code-changes-summary.md` - Technical implementation details
- `database-setup.md` - Database configuration guide

**Common issues & solutions available in each guide.**

---

## ✨ Success Indicators

You'll know everything is working when:

✅ Admin button appears for admin users only  
✅ Admin console opens without errors  
✅ Image file chooser shows JPG/PNG/GIF files  
✅ Image preview displays selected image  
✅ Product successfully adds to database  
✅ Image file copied to `images` folder  
✅ Product appears on main store page  
✅ Product image displays correctly  
✅ Non-admin users cannot see admin button  

---

**You're ready to go! Click the 🚀 and start managing products!**

Start with Creating your admin user → Login → Click ⚙️ Admin Console → Add Products! 🎉
