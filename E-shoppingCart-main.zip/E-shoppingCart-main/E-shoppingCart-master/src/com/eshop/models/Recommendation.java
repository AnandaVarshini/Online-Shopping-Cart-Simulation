package com.eshop.models;

public class Recommendation {
    private Product product;
    private double relevanceScore;
    private String reason;
    
    public Recommendation(Product product, double relevanceScore, String reason) {
        this.product = product;
        this.relevanceScore = relevanceScore;
        this.reason = reason;
    }
    
    public Product getProduct() {
        return product;
    }
    
    public void setProduct(Product product) {
        this.product = product;
    }
    
    public double getRelevanceScore() {
        return relevanceScore;
    }
    
    public void setRelevanceScore(double relevanceScore) {
        this.relevanceScore = relevanceScore;
    }
    
    public String getReason() {
        return reason;
    }
    
    public void setReason(String reason) {
        this.reason = reason;
    }
}
