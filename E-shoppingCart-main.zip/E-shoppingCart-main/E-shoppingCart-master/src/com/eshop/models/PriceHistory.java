package com.eshop.models;

import java.time.LocalDateTime;

public class PriceHistory {
    private int id;
    private int productId;
    private double price;
    private LocalDateTime recordedDate;
    private String priceChangeReason; // e.g., "Manual update", "Promotion", "Stock clearance"
    
    public PriceHistory() {}
    
    public PriceHistory(int productId, double price) {
        this.productId = productId;
        this.price = price;
        this.recordedDate = LocalDateTime.now();
        this.priceChangeReason = "Price Update";
    }
    
    public PriceHistory(int productId, double price, String reason) {
        this.productId = productId;
        this.price = price;
        this.recordedDate = LocalDateTime.now();
        this.priceChangeReason = reason;
    }
    
    public PriceHistory(int id, int productId, double price, LocalDateTime recordedDate, String reason) {
        this.id = id;
        this.productId = productId;
        this.price = price;
        this.recordedDate = recordedDate;
        this.priceChangeReason = reason;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public LocalDateTime getRecordedDate() { return recordedDate; }
    public void setRecordedDate(LocalDateTime recordedDate) { this.recordedDate = recordedDate; }
    
    public String getPriceChangeReason() { return priceChangeReason; }
    public void setPriceChangeReason(String reason) { this.priceChangeReason = reason; }
}
