package com.eshop.models;

import java.time.LocalDateTime;

public class Wishlist {
    private int id;
    private int userId;
    private int productId;
    private LocalDateTime addedDate;
    private double priceAtAdding;
    private boolean notificationEnabled;
    
    public Wishlist() {}
    
    public Wishlist(int userId, int productId, double priceAtAdding) {
        this.userId = userId;
        this.productId = productId;
        this.priceAtAdding = priceAtAdding;
        this.addedDate = LocalDateTime.now();
        this.notificationEnabled = true;
    }
    
    public Wishlist(int id, int userId, int productId, LocalDateTime addedDate, 
                    double priceAtAdding, boolean notificationEnabled) {
        this.id = id;
        this.userId = userId;
        this.productId = productId;
        this.addedDate = addedDate;
        this.priceAtAdding = priceAtAdding;
        this.notificationEnabled = notificationEnabled;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    
    public int getProductId() { return productId; }
    public void setProductId(int productId) { this.productId = productId; }
    
    public LocalDateTime getAddedDate() { return addedDate; }
    public void setAddedDate(LocalDateTime addedDate) { this.addedDate = addedDate; }
    
    public double getPriceAtAdding() { return priceAtAdding; }
    public void setPriceAtAdding(double priceAtAdding) { this.priceAtAdding = priceAtAdding; }
    
    public boolean isNotificationEnabled() { return notificationEnabled; }
    public void setNotificationEnabled(boolean notificationEnabled) { 
        this.notificationEnabled = notificationEnabled; 
    }
}
