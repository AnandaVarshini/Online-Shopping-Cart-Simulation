package com.eshop.models;

public class Product {
    private int id;
    private String name;
    private String description;
    private double price;
    private String imagePath;
    private byte[] imageData; // Binary image data (BLOB)
    private int stock;
    
    public Product() {}
    
    // Constructor without image data (for backwards compatibility)
    public Product(int id, String name, String description, double price, String imagePath, int stock) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imagePath = imagePath;
        this.imageData = null;
        this.stock = stock;
    }
    
    // Constructor with image data
    public Product(int id, String name, String description, double price, String imagePath, byte[] imageData, int stock) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.price = price;
        this.imagePath = imagePath;
        this.imageData = imageData;
        this.stock = stock;
    }
    
    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    
    public String getImagePath() { return imagePath; }
    public void setImagePath(String imagePath) { this.imagePath = imagePath; }
    
    public byte[] getImageData() { return imageData; }
    public void setImageData(byte[] imageData) { this.imageData = imageData; }
    
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    
    @Override
    public String toString() {
        return name + " - $" + price;
    }
}

