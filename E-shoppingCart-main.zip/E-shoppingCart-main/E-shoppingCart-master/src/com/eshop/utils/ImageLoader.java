package com.eshop.utils;

import com.eshop.database.ProductDAO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 * Image loader with database BLOB support
 * Loads product images from database and provides gradient fallback
 */
public class ImageLoader {
    
    /**
     * Load image from database using product ID
     * @param productId Product ID to load image for
     * @param width Desired image width
     * @param height Desired image height
     * @return ImageIcon with scaled image or gradient fallback
     */
    public static ImageIcon loadImage(int productId, int width, int height) {
        System.out.println("\n>>> ImageLoader.loadImage(productId=" + productId + ", " + width + "x" + height + ")");
        
        try {
            ProductDAO productDAO = new ProductDAO();
            
            // Get image data from database
            byte[] imageData = productDAO.getProductImageData(productId);
            
            System.out.println("    imageData from DB: " + (imageData != null ? imageData.length + " bytes" : "NULL"));
            
            if (imageData != null && imageData.length > 0) {
                try {
                    // Convert byte array to BufferedImage
                    ByteArrayInputStream bais = new ByteArrayInputStream(imageData);
                    BufferedImage img = ImageIO.read(bais);
                    
                    if (img != null) {
                        // Scale image to desired dimensions
                        Image scaledImage = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
                        System.out.println("    ✓ Image loaded successfully from database");
                        return new ImageIcon(scaledImage);
                    } else {
                        System.out.println("    ✗ ImageIO.read() returned null - invalid image format?");
                    }
                } catch (Exception e) {
                    System.err.println("    ✗ Error converting image data: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("    ⚠ No image data in database for product " + productId);
            }
        } catch (Exception e) {
            System.err.println("    ✗ Error loading image from database: " + e.getMessage());
            e.printStackTrace();
        }
        
        // Return gradient fallback if image not found or error occurred
        System.out.println("    -> Using fallback gradient");
        return createGradientFallback(width, height);
    }
    
    /**
     * Legacy method for backwards compatibility
     * This method is deprecated - use loadImage(int productId, ...) instead
     * @param imagePath Image filename reference (no longer used)
     * @param width Desired image width
     * @param height Desired image height
     * @return ImageIcon with gradient fallback
     */
    public static ImageIcon loadImage(String imagePath, int width, int height) {
        System.out.println("⚠ ImageLoader.loadImage(String) is deprecated. Images should be loaded from database.");
        System.out.println("  Please update calling code to use loadImage(int productId, width, height) instead");
        return createGradientFallback(width, height);
    }
    
    /**
     * Create colored gradient as fallback when image not found
     */
    private static ImageIcon createGradientFallback(int width, int height) {
        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
        // Light gray gradient with smooth transition
        GradientPaint gp = new GradientPaint(0, 0, new Color(200, 200, 200), 
                                            width, height, new Color(150, 150, 150));
        g2d.setPaint(gp);
        g2d.fillRect(0, 0, width, height);
        
        // Add placeholder text
        g2d.setColor(new Color(100, 100, 100));
        g2d.setFont(new Font("Arial", Font.PLAIN, 12));
        String text = "No Image";
        FontMetrics fm = g2d.getFontMetrics();
        int x = (width - fm.stringWidth(text)) / 2;
        int y = ((height - fm.getHeight()) / 2) + fm.getAscent();
        g2d.drawString(text, x, y);
        
        g2d.dispose();
        return new ImageIcon(img);
    }
}
