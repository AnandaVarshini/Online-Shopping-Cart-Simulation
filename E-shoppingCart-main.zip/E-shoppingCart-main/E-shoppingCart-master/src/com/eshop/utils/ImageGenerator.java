package com.eshop.utils;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Auto-generates placeholder product images on demand
 */
public class ImageGenerator {
    
    public static void generateMissingImages() {
        File imagesDir = new File("images");
        if (!imagesDir.exists()) {
            imagesDir.mkdirs();
        }
        
        // Products to generate: filename, icon, R, G, B
        Object[][] products = {
            new Object[] {"laptop.jpg", "💻", 100, 150, 200},
            new Object[] {"mobile.jpg", "📱", 25, 25, 112},
            new Object[] {"keyboard.jpg", "⌨️", 100, 180, 150},
            new Object[] {"monitor.jpg", "🖥️", 180, 120, 100},
            new Object[] {"headphone.jpg", "🎧", 150, 150, 100},
            new Object[] {"cable.jpg", "🔌", 100, 150, 150},
            new Object[] {"webcam.jpg", "📷", 180, 100, 100},
            new Object[] {"ssd.jpg", "💾", 70, 130, 180},
            new Object[] {"pendrive.jpg", "🔐", 34, 139, 34},            new Object[] {"mobile.jpg", "M", 25, 25, 112},
            new Object[] {"bluetooth.jpg", "B", 0, 150, 200},
            new Object[] {"smartwatch.jpg", "T", 128, 100, 128},
            new Object[] {"camera.jpg", "C", 105, 105, 105},
            new Object[] {"scanner.jpg", "S", 150, 150, 150},
            new Object[] {"speaker.jpg", "P", 200, 100, 50},            new Object[] {"bluetooth.jpg", "📡", 0, 191, 255},
            new Object[] {"smartwatch.jpg", "⌚", 128, 0, 128},
            new Object[] {"camera.jpg", "📸", 105, 105, 105},
            new Object[] {"scanner.jpg", "🖨️", 169, 169, 169},
            new Object[] {"speaker.jpg", "🔊", 255, 140, 0},
            new Object[] {"printer.jpg", "🖨️", 100, 100, 100}




        };
        
        for (Object[] product : products) {
            String filename = (String) product[0];
            String icon = (String) product[1];
            int r = (int) product[2];
            int g = (int) product[3];
            int b = (int) product[4];
            
            File file = new File(imagesDir, filename);
            if (!file.exists()) {
                createImage(filename, icon, r, g, b);
            }
        }
    }
    
    private static void createImage(String filename, String icon, int r, int g, int b) {
        try {
            BufferedImage img = new BufferedImage(300, 300, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = img.createGraphics();
            g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            
            // Gradient background
            GradientPaint gp = new GradientPaint(0, 0, new Color(r, g, b), 300, 300, new Color(r-30, g-30, b-30));
            g2d.setPaint(gp);
            g2d.fillRect(0, 0, 300, 300);
            
            // Emoji icon
            g2d.setFont(new Font("Arial", Font.BOLD, 120));
            g2d.setColor(Color.WHITE);
            FontMetrics fm = g2d.getFontMetrics();
            int x = (300 - fm.stringWidth(icon)) / 2;
            int y = 150 + fm.getAscent() / 2;
            g2d.drawString(icon, x, y);
            
            g2d.dispose();
            ImageIO.write(img, "jpg", new File("images", filename));
            System.out.println("✓ Generated image: " + filename);
        } catch (Exception e) {
            System.err.println("⚠ Failed to generate: " + filename);
        }
    }
}

