package com.eshop.ui;

import com.eshop.database.ProductDAO;
import com.eshop.database.RecommendationDAO;
import com.eshop.models.*;
import com.eshop.utils.ImageLoader;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class MainFrame extends JFrame {
    private final User currentUser;
    private final ShoppingCart cart;
    private final ProductDAO productDAO;
    private final RecommendationDAO recommendationDAO;
    private final DecimalFormat df = new DecimalFormat("$#,##0.00");
    
    // UI Components
    private JPanel productPanel;
    private JLabel lblCartCount, lblCartTotal, lblWishlistCount;
    private JButton btnViewCart, btnMyAccount, btnLogout, btnWishlist;

    public MainFrame(User user) {
        this.currentUser = user;
        this.cart = new ShoppingCart();
        this.productDAO = new ProductDAO();
        this.recommendationDAO = new RecommendationDAO();
        
        initUI();
        loadProducts();
        updateWishlistCount();
    }

    private void initUI() {
        setTitle("E-Shop - Welcome " + currentUser.getFullName());
        setSize(1000, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        // Main panel setup
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));
        
        // Create and add header
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Product listings panel
        productPanel = new JPanel();
        productPanel.setLayout(new BoxLayout(productPanel, BoxLayout.Y_AXIS));
        productPanel.setBackground(new Color(245, 245, 245));
        
        JScrollPane scrollPane = new JScrollPane(productPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(null);
        
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        add(mainPanel);
    }

    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        // Store title
        JLabel lblStore = new JLabel("E-Shop");
        lblStore.setFont(new Font("SansSerif", Font.BOLD, 28));
        lblStore.setForeground(Color.WHITE);
        
        // Cart info panel
        JPanel cartPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        cartPanel.setOpaque(false);
        
        lblCartCount = new JLabel("Cart: 0 items");
        lblCartTotal = new JLabel("Total: $0.00");
        lblWishlistCount = new JLabel("❤️ 0");
        styleCartLabels();
        
        btnViewCart = new JButton("View Cart");
        btnWishlist = new JButton("Wishlist");
        JButton btnRefresh = new JButton("🔄 Refresh");
        styleButton(btnViewCart, new Color(50, 110, 160));
        styleButton(btnWishlist, new Color(180, 50, 50)); // Red for wishlist
        styleButton(btnRefresh, new Color(100, 150, 100)); // Green for refresh
        
        cartPanel.add(lblWishlistCount);
        cartPanel.add(btnWishlist);
        cartPanel.add(Box.createHorizontalStrut(10));
        cartPanel.add(lblCartCount);
        cartPanel.add(Box.createHorizontalStrut(10));
        cartPanel.add(lblCartTotal);
        cartPanel.add(Box.createHorizontalStrut(20));
        cartPanel.add(btnRefresh);
        cartPanel.add(Box.createHorizontalStrut(10));
        cartPanel.add(btnViewCart);
        
        // User panel
        JPanel userPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        userPanel.setOpaque(false);
        
        btnMyAccount = new JButton("My Account");
        btnLogout = new JButton("Logout");
        styleButton(btnMyAccount, new Color(50, 110, 160));
        styleButton(btnLogout, new Color(50, 110, 160));
        
        // Add admin console button only for admins
        if ("admin".equalsIgnoreCase(currentUser.getRole())) {
            JButton btnAdminConsole = new JButton("⚙️ Admin Console");
            btnAdminConsole.setFont(new Font("Arial", Font.BOLD, 11));
            btnAdminConsole.setBackground(new Color(220, 100, 50)); // Orange for admin
            btnAdminConsole.setForeground(Color.WHITE);
            btnAdminConsole.setFocusPainted(false);
            btnAdminConsole.addActionListener(e -> openAdminConsole());
            userPanel.add(btnAdminConsole);
            userPanel.add(Box.createHorizontalStrut(5));
        }
        
        userPanel.add(btnMyAccount);
        userPanel.add(Box.createHorizontalStrut(5));
        userPanel.add(btnLogout);
        
        // Combine panels
        JPanel rightPanel = new JPanel(new BorderLayout());
        rightPanel.setOpaque(false);
        rightPanel.add(cartPanel, BorderLayout.CENTER);
        rightPanel.add(userPanel, BorderLayout.EAST);
        
        headerPanel.add(lblStore, BorderLayout.WEST);
        headerPanel.add(rightPanel, BorderLayout.EAST);
        
        // Add action listeners
        btnViewCart.addActionListener(e -> viewCart());
        btnWishlist.addActionListener(e -> viewWishlist());
        btnRefresh.addActionListener(e -> refreshProducts());
        btnMyAccount.addActionListener(e -> viewAccount());
        btnLogout.addActionListener(e -> logout());
        
        return headerPanel;
    }

    private void styleCartLabels() {
        lblCartCount.setForeground(Color.WHITE);
        lblCartCount.setFont(new Font("Arial", Font.PLAIN, 14));
        lblCartTotal.setForeground(Color.WHITE);
        lblCartTotal.setFont(new Font("Arial", Font.PLAIN, 14));
    }

    private void styleButton(JButton button, Color bgColor) {
        button.setBackground(bgColor);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
    }

    private void loadProducts() {
        try {
            productPanel.removeAll();
            
            // Load and display recommendations
            loadRecommendations();
            
            // Load and display all products
            List<Product> products = productDAO.getAllProducts();
            
            if (products.isEmpty()) {
                productPanel.add(new JLabel("No products available", SwingConstants.CENTER));
            } else {
                for (Product product : products) {
                    productPanel.add(createProductCard(product));
                    productPanel.add(Box.createVerticalStrut(10));
                }
            }
            productPanel.revalidate();
            productPanel.repaint();
        } catch (SQLException ex) {
            showError("Error loading products: " + ex.getMessage());
        }
    }
    
    private void loadRecommendations() {
        try {
            List<Recommendation> recommendations = recommendationDAO.getRecommendationsForUser(
                currentUser.getId(), 4);
            
            if (!recommendations.isEmpty()) {
                // Show personalized recommendations
                productPanel.add(createRecommendationSection(recommendations, true));
                productPanel.add(Box.createVerticalStrut(15));
            } else {
                // Show popular products for new users
                List<Recommendation> popularProducts = recommendationDAO.getPopularProducts(4);
                if (!popularProducts.isEmpty()) {
                    productPanel.add(createRecommendationSection(popularProducts, false));
                    productPanel.add(Box.createVerticalStrut(15));
                }
            }
        } catch (SQLException ex) {
            System.err.println("Error loading recommendations: " + ex.getMessage());
        }
    }
    
    private JPanel createRecommendationSection(List<Recommendation> recommendations, boolean isPersonalized) {
        JPanel mainSection = new JPanel();
        mainSection.setLayout(new BoxLayout(mainSection, BoxLayout.Y_AXIS));
        mainSection.setBackground(new Color(245, 245, 245));
        mainSection.setMaximumSize(new Dimension(Integer.MAX_VALUE, 350));
        
        // Header with gradient-like styling
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(new EmptyBorder(12, 15, 12, 15));
        headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        
        JLabel lblRecommended = new JLabel(isPersonalized ? "✨ Recommended For You" : "🔥 Popular Products");
        lblRecommended.setFont(new Font("Arial", Font.BOLD, 18));
        lblRecommended.setForeground(Color.WHITE);
        
        JLabel lblInfo = new JLabel(isPersonalized ? "Based on your purchase history and preferences" : "Trending products - Check them out!");
        lblInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        lblInfo.setForeground(new Color(220, 220, 220));
        
        JPanel textPanel = new JPanel(new BorderLayout(5, 0));
        textPanel.setOpaque(false);
        textPanel.add(lblRecommended, BorderLayout.CENTER);
        textPanel.add(lblInfo, BorderLayout.SOUTH);
        
        headerPanel.add(textPanel, BorderLayout.WEST);
        mainSection.add(headerPanel);
        
        // Cards panel with horizontal scroll
        JPanel cardsPanel = new JPanel();
        cardsPanel.setLayout(new BoxLayout(cardsPanel, BoxLayout.X_AXIS));
        cardsPanel.setBackground(new Color(245, 245, 245));
        cardsPanel.setBorder(new EmptyBorder(10, 0, 10, 0));
        
        for (Recommendation rec : recommendations) {
            cardsPanel.add(createRecommendationCard(rec));
            cardsPanel.add(Box.createHorizontalStrut(10));
        }
        cardsPanel.add(Box.createHorizontalGlue());
        
        JScrollPane scrollPane = new JScrollPane(cardsPanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));
        
        mainSection.add(scrollPane);
        
        return mainSection;
    }
    
    private JPanel createPopularProductsSection(List<Product> products) {
        JPanel mainSection = new JPanel();
        mainSection.setLayout(new BoxLayout(mainSection, BoxLayout.Y_AXIS));
        mainSection.setBackground(new Color(245, 245, 245));
        mainSection.setMaximumSize(new Dimension(Integer.MAX_VALUE, 350));
        
        // Header with gradient-like styling
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(220, 100, 50)); // Orange for Popular
        headerPanel.setBorder(new EmptyBorder(12, 15, 12, 15));
        headerPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 50));
        
        JLabel lblPopular = new JLabel("🔥 Popular Products");
        lblPopular.setFont(new Font("Arial", Font.BOLD, 18));
        lblPopular.setForeground(Color.WHITE);
        
        JLabel lblInfo = new JLabel("Trending products - Check them out!");
        lblInfo.setFont(new Font("Arial", Font.PLAIN, 12));
        lblInfo.setForeground(new Color(255, 220, 200));
        
        JPanel textPanel = new JPanel(new BorderLayout(5, 0));
        textPanel.setOpaque(false);
        textPanel.add(lblPopular, BorderLayout.CENTER);
        textPanel.add(lblInfo, BorderLayout.SOUTH);
        
        headerPanel.add(textPanel, BorderLayout.WEST);
        mainSection.add(headerPanel);
        
        // Cards panel with horizontal scroll
        JPanel cardsPanel = new JPanel();
        cardsPanel.setLayout(new BoxLayout(cardsPanel, BoxLayout.X_AXIS));
        cardsPanel.setBackground(new Color(245, 245, 245));
        cardsPanel.setBorder(new EmptyBorder(10, 0, 10, 0));
        
        for (Product product : products) {
            cardsPanel.add(createPopularProductCard(product));
            cardsPanel.add(Box.createHorizontalStrut(10));
        }
        cardsPanel.add(Box.createHorizontalGlue());
        
        JScrollPane scrollPane = new JScrollPane(cardsPanel);
        scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.setMaximumSize(new Dimension(Integer.MAX_VALUE, 280));
        
        mainSection.add(scrollPane);
        
        return mainSection;
    }
    
    private JPanel createPopularProductCard(Product product) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setPreferredSize(new Dimension(220, 260));
        card.setMaximumSize(new Dimension(220, 260));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 150, 100), 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Image panel - Load actual image or use gradient fallback
        JPanel imagePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw gradient background as fallback
                Color[] colors = {new Color(255, 150, 80), new Color(220, 100, 50)};
                int[] x = {0, 0};
                int[] y = {0, getHeight()};
                GradientPaint gp = new GradientPaint(x[0], y[0], colors[0], x[1], y[1], colors[1]);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        imagePanel.setPreferredSize(new Dimension(200, 100));
        imagePanel.setBackground(new Color(255, 150, 80));
        
        // Try to load actual image
        ImageIcon imageIcon = ImageLoader.loadImage(product.getId(), 200, 100);
        JLabel imageLabel = new JLabel(imageIcon, SwingConstants.CENTER);
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        
        // Popular badge
        JLabel lblPopular = new JLabel("⭐ Popular");
        lblPopular.setFont(new Font("Arial", Font.BOLD, 11));
        lblPopular.setForeground(new Color(255, 100, 0));
        
        // Product details
        JLabel lblName = new JLabel(product.getName());
        lblName.setFont(new Font("Arial", Font.BOLD, 13));
        lblName.setForeground(new Color(50, 50, 50));
        
        JLabel lblDesc = new JLabel("In high demand");
        lblDesc.setFont(new Font("Arial", Font.ITALIC, 10));
        lblDesc.setForeground(new Color(120, 120, 120));
        
        JLabel lblPrice = new JLabel(df.format(product.getPrice()));
        lblPrice.setFont(new Font("Arial", Font.BOLD, 14));
        lblPrice.setForeground(new Color(220, 100, 50));
        
        JLabel lblStock = new JLabel("Stock: " + product.getStock());
        lblStock.setFont(new Font("Arial", Font.PLAIN, 10));
        lblStock.setForeground(new Color(100, 100, 100));
        
        // Add to cart button
        JButton btnAdd = new JButton("Add to Cart");
        btnAdd.setFont(new Font("Arial", Font.BOLD, 11));
        btnAdd.setBackground(new Color(220, 100, 50));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFocusPainted(false);
        btnAdd.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        btnAdd.addActionListener(e -> addToCart(product, 1));
        
        // Layout
        JPanel infoPanel = new JPanel(new BorderLayout(5, 3));
        infoPanel.setOpaque(false);
        
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);
        textPanel.add(lblPopular);
        textPanel.add(Box.createVerticalStrut(2));
        textPanel.add(lblName);
        textPanel.add(lblDesc);
        textPanel.add(Box.createVerticalStrut(3));
        textPanel.add(lblPrice);
        textPanel.add(lblStock);
        
        infoPanel.add(textPanel, BorderLayout.CENTER);
        infoPanel.add(btnAdd, BorderLayout.SOUTH);
        
        card.add(imagePanel, BorderLayout.NORTH);
        card.add(infoPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createRecommendationCard(Recommendation recommendation) {
        Product product = recommendation.getProduct();
        
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setPreferredSize(new Dimension(220, 260));
        card.setMaximumSize(new Dimension(220, 260));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        // Image panel - Load actual image or use gradient fallback
        JPanel imagePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw gradient background as fallback
                Color[] colors = {new Color(100, 150, 200), new Color(70, 130, 180)};
                int[] x = {0, 0};
                int[] y = {0, getHeight()};
                GradientPaint gp = new GradientPaint(x[0], y[0], colors[0], x[1], y[1], colors[1]);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        imagePanel.setPreferredSize(new Dimension(200, 100));
        imagePanel.setBackground(new Color(100, 150, 200));
        
        // Try to load actual image
        ImageIcon imageIcon = ImageLoader.loadImage(product.getId(), 200, 100);
        JLabel imageLabel = new JLabel(imageIcon, SwingConstants.CENTER);
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        
        // Recommendation badge
        JLabel lblScore = new JLabel(String.format("⭐ %.0f%%", recommendation.getRelevanceScore() * 100));
        lblScore.setFont(new Font("Arial", Font.BOLD, 11));
        lblScore.setForeground(new Color(255, 140, 0));
        
        // Product details
        JLabel lblName = new JLabel(product.getName());
        lblName.setFont(new Font("Arial", Font.BOLD, 13));
        lblName.setForeground(new Color(50, 50, 50));
        
        JLabel lblReason = new JLabel(recommendation.getReason());
        lblReason.setFont(new Font("Arial", Font.ITALIC, 10));
        lblReason.setForeground(new Color(120, 120, 120));
        
        JLabel lblPrice = new JLabel(df.format(product.getPrice()));
        lblPrice.setFont(new Font("Arial", Font.BOLD, 14));
        lblPrice.setForeground(new Color(70, 130, 180));
        
        JLabel lblStock = new JLabel("Stock: " + product.getStock());
        lblStock.setFont(new Font("Arial", Font.PLAIN, 10));
        lblStock.setForeground(new Color(100, 100, 100));
        
        // Add to cart button
        JButton btnAdd = new JButton("Add to Cart");
        btnAdd.setFont(new Font("Arial", Font.BOLD, 11));
        btnAdd.setBackground(new Color(70, 130, 180));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFocusPainted(false);
        btnAdd.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        btnAdd.addActionListener(e -> addToCart(product, 1));
        
        // Layout
        JPanel infoPanel = new JPanel(new BorderLayout(5, 3));
        infoPanel.setOpaque(false);
        
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
        textPanel.setOpaque(false);
        textPanel.add(lblScore);
        textPanel.add(Box.createVerticalStrut(2));
        textPanel.add(lblName);
        textPanel.add(lblReason);
        textPanel.add(Box.createVerticalStrut(3));
        textPanel.add(lblPrice);
        textPanel.add(lblStock);
        
        infoPanel.add(textPanel, BorderLayout.CENTER);
        infoPanel.add(btnAdd, BorderLayout.SOUTH);
        
        card.add(imagePanel, BorderLayout.NORTH);
        card.add(infoPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private String getProductIcon(String productName) {
        String name = productName.toLowerCase();
        if (name.contains("laptop")) return "💻";
        if (name.contains("mouse")) return "🖱️";
        if (name.contains("keyboard")) return "⌨️";
        if (name.contains("monitor")) return "🖥️";
        if (name.contains("headphone")) return "🎧";
        if (name.contains("cable") || name.contains("usb")) return "🔗";
        if (name.contains("webcam")) return "📷";
        if (name.contains("ssd") || name.contains("external")) return "💾";
        return "📦";
    }

    private JPanel createProductCard(Product product) {
        JPanel card = new JPanel(new BorderLayout(10, 10));
        card.setMaximumSize(new Dimension(800, 200));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createEmptyBorder(10, 10, 10, 10),
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1)
        ));
        
        // Image panel - Load actual image or use gradient fallback
        JPanel imagePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                // Draw gradient background as fallback
                Color[] colors = getProductColors(product.getName());
                GradientPaint gp = new GradientPaint(0, 0, colors[0], getWidth(), getHeight(), colors[1]);
                g2d.setPaint(gp);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };
        imagePanel.setPreferredSize(new Dimension(150, 150));
        
        // Try to load actual image
        ImageIcon imageIcon = ImageLoader.loadImage(product.getId(), 150, 150);
        JLabel imageLabel = new JLabel(imageIcon, SwingConstants.CENTER);
        imagePanel.add(imageLabel, BorderLayout.CENTER);
        
        // Product details panel
        JPanel detailsPanel = new JPanel(new BorderLayout(10, 10));
        detailsPanel.setBackground(Color.WHITE);
        
        // Product info
        JLabel lblName = new JLabel(product.getName());
        lblName.setFont(new Font("Arial", Font.BOLD, 16));
        
        JTextArea txtDescription = new JTextArea(product.getDescription());
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        txtDescription.setEditable(false);
        txtDescription.setBackground(Color.WHITE);
        txtDescription.setFont(new Font("Arial", Font.PLAIN, 12));
        
        // Price and stock
        JLabel lblPrice = new JLabel(df.format(product.getPrice()));
        lblPrice.setFont(new Font("Arial", Font.BOLD, 18));
        lblPrice.setForeground(new Color(70, 130, 180));
        
        JLabel lblStock = new JLabel(product.getStock() > 0 ? 
            "In Stock: " + product.getStock() : "❌ Out of Stock");
        lblStock.setFont(new Font("Arial", Font.ITALIC, 12));
        lblStock.setForeground(product.getStock() > 0 ? 
            new Color(100, 100, 100) : new Color(200, 50, 50));
        
        // Quantity controls
        int maxStock = Math.max(product.getStock(), 1); // Ensure at least 1 for spinner
        JSpinner spinner = new JSpinner(
            new SpinnerNumberModel(1, 1, maxStock, 1));
        spinner.setPreferredSize(new Dimension(60, 30));
        spinner.setEnabled(product.getStock() > 0); // Disable if out of stock
        
        JButton btnAddToCart = new JButton("Add to Cart");
        styleButton(btnAddToCart, new Color(70, 130, 180));
        btnAddToCart.setEnabled(product.getStock() > 0); // Disable if out of stock
        btnAddToCart.addActionListener(e -> addToCart(product, (int)spinner.getValue()));
        
        JButton btnWishlistAdd = new JButton("❤️ Wishlist");
        styleButton(btnWishlistAdd, new Color(180, 50, 50));
        btnWishlistAdd.addActionListener(e -> addToWishlist(product));
        
        // Layout components
        JPanel infoPanel = new JPanel(new BorderLayout(5, 10));
        infoPanel.setOpaque(false);
        infoPanel.add(lblName, BorderLayout.NORTH);
        infoPanel.add(txtDescription, BorderLayout.CENTER);
        
        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actionPanel.setOpaque(false);
        actionPanel.add(new JLabel("Qty:"));
        actionPanel.add(spinner);
        actionPanel.add(btnWishlistAdd);
        actionPanel.add(btnAddToCart);
        
        JPanel pricePanel = new JPanel(new BorderLayout(5, 10));
        pricePanel.setOpaque(false);
        pricePanel.add(lblPrice, BorderLayout.NORTH);
        pricePanel.add(lblStock, BorderLayout.CENTER);
        pricePanel.add(actionPanel, BorderLayout.SOUTH);
        
        detailsPanel.add(infoPanel, BorderLayout.CENTER);
        detailsPanel.add(pricePanel, BorderLayout.EAST);
        
        card.add(imagePanel, BorderLayout.WEST);
        card.add(detailsPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private Color[] getProductColors(String productName) {
        String name = productName.toLowerCase();
        if (name.contains("laptop")) return new Color[]{new Color(100, 150, 200), new Color(70, 110, 180)};
        if (name.contains("mouse")) return new Color[]{new Color(150, 100, 150), new Color(120, 70, 150)};
        if (name.contains("keyboard")) return new Color[]{new Color(100, 180, 150), new Color(70, 150, 120)};
        if (name.contains("monitor")) return new Color[]{new Color(180, 120, 100), new Color(150, 90, 70)};
        if (name.contains("headphone")) return new Color[]{new Color(150, 150, 100), new Color(120, 120, 70)};
        if (name.contains("cable") || name.contains("usb")) return new Color[]{new Color(100, 150, 150), new Color(70, 120, 120)};
        if (name.contains("webcam")) return new Color[]{new Color(180, 100, 100), new Color(150, 70, 70)};
        if (name.contains("ssd") || name.contains("external")) return new Color[]{new Color(130, 100, 180), new Color(100, 70, 150)};
        if (name.contains("pendrive")) return new Color[]{new Color(34, 139, 34), new Color(0, 100, 0)};
        if (name.contains("mobile")) return new Color[]{new Color(25, 25, 112), new Color(0, 0, 80)};
        if (name.contains("bluetooth")) return new Color[]{new Color(0, 150, 200), new Color(0, 100, 150)};
        if (name.contains("smartwatch")) return new Color[]{new Color(128, 100, 128), new Color(100, 70, 100)};
        if (name.contains("camera") || name.contains("webcam")) return new Color[]{new Color(105, 105, 105), new Color(70, 70, 70)};
        if (name.contains("scanner")) return new Color[]{new Color(150, 150, 150), new Color(100, 100, 100)};
        if (name.contains("speaker")) return new Color[]{new Color(200, 100, 50), new Color(150, 70, 30)};
        return new Color[]{new Color(120, 120, 150), new Color(90, 90, 120)};
    }

    private void addToCart(Product product, int quantity) {
        try {
            cart.addItem(product, quantity);
            updateCartInfo();
            showSuccess("Added " + quantity + " × " + product.getName() + " to cart");
        } catch (IllegalArgumentException ex) {
            showError(ex.getMessage());
        }
    }

    private void updateCartInfo() {
        lblCartCount.setText("Cart: " + cart.getItemCount() + " items");
        lblCartTotal.setText("Total: " + df.format(cart.getTotal()));
    }

    private void viewCart() {
        if (cart.getItems().isEmpty()) {
            showInfo("Your cart is empty");
            return;
        }
        new CartFrame(this, cart, currentUser).setVisible(true);
    }

    private void viewAccount() {
        new AccountFrame(currentUser).setVisible(true);
    }

    private void viewWishlist() {
        new WishlistFrame(currentUser, this).setVisible(true);
    }

    private void logout() {
        if (JOptionPane.YES_OPTION == JOptionPane.showConfirmDialog(this,
            "Are you sure you want to logout?", "Logout Confirmation",
            JOptionPane.YES_NO_OPTION)) {
            dispose();
            new LoginFrame().setVisible(true);
        }
    }

    private void openAdminConsole() {
        new AdminDashboard(currentUser);
    }

    private void addToWishlist(Product product) {
        try {
            com.eshop.database.WishlistDAO wishlistDAO = new com.eshop.database.WishlistDAO();
            
            if (wishlistDAO.isProductInWishlist(currentUser.getId(), product.getId())) {
                showInfo("This product is already in your wishlist!");
            } else {
                int wishlistId = wishlistDAO.addToWishlist(
                    currentUser.getId(), 
                    product.getId(), 
                    product.getPrice()
                );
                
                if (wishlistId > 0) {
                    showSuccess("Added to wishlist! ❤️");
                    updateWishlistCount();
                } else {
                    showError("Failed to add to wishlist");
                }
            }
        } catch (SQLException ex) {
            showError("Error: " + ex.getMessage());
        }
    }

    public void updateWishlistCount() {
        try {
            com.eshop.database.WishlistDAO wishlistDAO = new com.eshop.database.WishlistDAO();
            int count = wishlistDAO.getWishlistCount(currentUser.getId());
            lblWishlistCount.setText("❤️ " + count);
        } catch (SQLException ex) {
            System.err.println("Error updating wishlist count: " + ex.getMessage());
        }
    }

    public void refreshCart() {
        updateCartInfo();
        updateWishlistCount(); // Also update wishlist count when cart is refreshed
    }
    
    public void refreshProducts() {
        loadProducts();
        updateWishlistCount();
    }

    // Public method to add items to cart from wishlist or other sources
    public void addItemToCart(Product product, int quantity) {
        addToCart(product, quantity);
    }

    // Helper methods for dialogs
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(this, message, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
}