package com.eshop.ui;

import com.eshop.database.DatabaseConnection;
import com.eshop.models.User;
import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class AdminDashboard extends JFrame {

    private JTextField txtName, txtPrice, txtStock;
    private JTextArea txtDescription;
    private JButton btnAdd, btnSelectImage, btnClear;
    private JLabel lblImagePreview, lblSelectedFile;
    private File selectedImageFile = null;
    private User currentUser;

    public AdminDashboard(User user) {
        this.currentUser = user;
        
        // Check if user is admin
        if (!isAdminUser()) {
            JOptionPane.showMessageDialog(null, 
                "Access Denied! Only admins can access the Admin Dashboard.",
                "Permission Denied", JOptionPane.WARNING_MESSAGE);
            dispose();
            return;
        }

        initUI();
    }

    private void initUI() {
        setTitle("Admin Dashboard - Product Management ⚙️");
        setSize(700, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));

        // Header
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        JLabel heading = new JLabel("Add New Product");
        heading.setFont(new Font("Arial", Font.BOLD, 24));
        heading.setForeground(Color.WHITE);

        JLabel adminLabel = new JLabel("👤 Admin: " + currentUser.getFullName());
        adminLabel.setFont(new Font("Arial", Font.PLAIN, 12));
        adminLabel.setForeground(new Color(220, 220, 220));

        JPanel headerTextPanel = new JPanel(new BorderLayout());
        headerTextPanel.setOpaque(false);
        headerTextPanel.add(heading, BorderLayout.NORTH);
        headerTextPanel.add(adminLabel, BorderLayout.SOUTH);

        headerPanel.add(headerTextPanel, BorderLayout.WEST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        // Main content panel with scroll
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBackground(Color.WHITE);
        contentPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        // Product Details Section
        JPanel detailsSection = createSection("Product Details", 
            createProductDetailsPanel());
        contentPanel.add(detailsSection);
        contentPanel.add(Box.createVerticalStrut(10));

        // Image Upload Section
        JPanel imageSection = createSection("Product Image", 
            createImageUploadPanel());
        contentPanel.add(imageSection);
        contentPanel.add(Box.createVerticalStrut(10));

        // Buttons Section
        JPanel buttonsPanel = createButtonsPanel();
        contentPanel.add(buttonsPanel);

        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(null);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createSection(String title, JPanel content) {
        JPanel section = new JPanel(new BorderLayout());
        section.setBackground(Color.WHITE);
        section.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(200, 200, 200)),
            new EmptyBorder(10, 0, 15, 0)
        ));

        JLabel sectionTitle = new JLabel("  " + title);
        sectionTitle.setFont(new Font("Arial", Font.BOLD, 14));
        sectionTitle.setForeground(new Color(70, 130, 180));

        section.add(sectionTitle, BorderLayout.NORTH);
        section.add(content, BorderLayout.CENTER);

        return section;
    }

    private JPanel createProductDetailsPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Product Name
        gbc.gridx = 0; gbc.gridy = 0; gbc.weightx = 0.2;
        panel.add(createLabel("Product Name:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.8;
        txtName = new JTextField(20);
        panel.add(txtName, gbc);

        // Description
        gbc.gridx = 0; gbc.gridy = 1; gbc.weightx = 0.2; gbc.anchor = GridBagConstraints.NORTH;
        panel.add(createLabel("Description:"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.8;
        txtDescription = new JTextArea(4, 20);
        txtDescription.setLineWrap(true);
        txtDescription.setWrapStyleWord(true);
        JScrollPane descScroll = new JScrollPane(txtDescription);
        descScroll.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        panel.add(descScroll, gbc);

        // Price
        gbc.gridx = 0; gbc.gridy = 2; gbc.weightx = 0.2; gbc.anchor = GridBagConstraints.CENTER;
        panel.add(createLabel("Price ($):"), gbc);
        gbc.gridx = 1; gbc.weightx = 0.8;
        txtPrice = new JTextField(20);
        panel.add(txtPrice, gbc);

        // Stock
        gbc.gridx = 0; gbc.gridy = 3;
        panel.add(createLabel("Stock Quantity:"), gbc);
        gbc.gridx = 1;
        txtStock = new JTextField(20);
        panel.add(txtStock, gbc);

        return panel;
    }

    private JPanel createImageUploadPanel() {
        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout(10, 10));
        panel.setOpaque(false);

        // Left side: Preview
        JPanel previewPanel = new JPanel(new BorderLayout());
        previewPanel.setBackground(new Color(240, 240, 240));
        previewPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 2));
        previewPanel.setPreferredSize(new Dimension(200, 200));

        lblImagePreview = new JLabel("No image selected", SwingConstants.CENTER);
        lblImagePreview.setFont(new Font("Arial", Font.ITALIC, 12));
        lblImagePreview.setForeground(new Color(120, 120, 120));
        previewPanel.add(lblImagePreview, BorderLayout.CENTER);

        // Right side: Selection
        JPanel selectionPanel = new JPanel();
        selectionPanel.setLayout(new BoxLayout(selectionPanel, BoxLayout.Y_AXIS));
        selectionPanel.setOpaque(false);

        btnSelectImage = new JButton("📁 Choose Image File");
        btnSelectImage.setFont(new Font("Arial", Font.BOLD, 12));
        btnSelectImage.setBackground(new Color(100, 180, 150));
        btnSelectImage.setForeground(Color.WHITE);
        btnSelectImage.setFocusPainted(false);
        btnSelectImage.setAlignmentX(Component.LEFT_ALIGNMENT);
        btnSelectImage.addActionListener(e -> selectImageFile());

        lblSelectedFile = new JLabel("Selected: None");
        lblSelectedFile.setFont(new Font("Arial", Font.PLAIN, 11));
        lblSelectedFile.setForeground(new Color(100, 100, 100));
        lblSelectedFile.setAlignmentX(Component.LEFT_ALIGNMENT);

        selectionPanel.add(btnSelectImage);
        selectionPanel.add(Box.createVerticalStrut(10));
        selectionPanel.add(lblSelectedFile);
        selectionPanel.add(Box.createVerticalStrut(10));

        JLabel infoLabel = new JLabel("✓ Supported: JPG, PNG, GIF");
        infoLabel.setFont(new Font("Arial", Font.ITALIC, 10));
        infoLabel.setForeground(new Color(120, 120, 120));
        infoLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        selectionPanel.add(infoLabel);

        panel.add(previewPanel, BorderLayout.WEST);
        panel.add(selectionPanel, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createButtonsPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 10));
        panel.setOpaque(false);

        btnAdd = new JButton("✅ Add Product");
        btnAdd.setFont(new Font("Arial", Font.BOLD, 13));
        btnAdd.setBackground(new Color(70, 180, 120));
        btnAdd.setForeground(Color.WHITE);
        btnAdd.setFocusPainted(false);
        btnAdd.setPreferredSize(new Dimension(150, 40));
        btnAdd.addActionListener(e -> addProduct());

        btnClear = new JButton("🔄 Clear");
        btnClear.setFont(new Font("Arial", Font.BOLD, 13));
        btnClear.setBackground(new Color(200, 100, 100));
        btnClear.setForeground(Color.WHITE);
        btnClear.setFocusPainted(false);
        btnClear.setPreferredSize(new Dimension(150, 40));
        btnClear.addActionListener(e -> clearForm());

        panel.add(btnAdd);
        panel.add(btnClear);

        return panel;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Arial", Font.BOLD, 12));
        label.setForeground(new Color(50, 50, 50));
        return label;
    }

    private void selectImageFile() {
        JFileChooser fileChooser = new JFileChooser();
        fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter(
            "Image files (JPG, PNG, GIF)", "jpg", "jpeg", "png", "gif"));
        fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

        int result = fileChooser.showOpenDialog(this);
        if (result == JFileChooser.APPROVE_OPTION) {
            selectedImageFile = fileChooser.getSelectedFile();
            
            // Show file name
            lblSelectedFile.setText("Selected: " + selectedImageFile.getName());
            
            // Show preview
            ImageIcon icon = new ImageIcon(selectedImageFile.getAbsolutePath());
            Image scaledImage = icon.getImage().getScaledInstance(180, 180, Image.SCALE_SMOOTH);
            lblImagePreview.setIcon(new ImageIcon(scaledImage));
            lblImagePreview.setText("");
        }
    }

    private void addProduct() {
        try {
            // Validate inputs
            String name = txtName.getText().trim();
            String description = txtDescription.getText().trim();
            String priceStr = txtPrice.getText().trim();
            String stockStr = txtStock.getText().trim();

            if (name.isEmpty() || description.isEmpty() || priceStr.isEmpty() || stockStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, 
                    "Please fill in all product details!", 
                    "Missing Information", JOptionPane.WARNING_MESSAGE);
                return;
            }

            if (selectedImageFile == null) {
                JOptionPane.showMessageDialog(this, 
                    "Please select a product image!", 
                    "Missing Image", JOptionPane.WARNING_MESSAGE);
                return;
            }

            double price = Double.parseDouble(priceStr);
            int stock = Integer.parseInt(stockStr);

            if (price <= 0 || stock < 0) {
                JOptionPane.showMessageDialog(this, 
                    "Price must be positive and stock must be non-negative!", 
                    "Invalid Input", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Read image file as bytes
            byte[] imageData = Files.readAllBytes(selectedImageFile.toPath());
            
            // Use original image filename only (no timestamp)
            String imageFileName = selectedImageFile.getName();

            System.out.println("\n=== ADMIN DASHBOARD: Adding Product ===");
            System.out.println("Product Name: " + name);
            System.out.println("Image File: " + imageFileName);
            System.out.println("Image Size: " + imageData.length + " bytes");

            // Insert product into database with image filename and BLOB data
            Connection con = DatabaseConnection.getConnection();
            String sql = "INSERT INTO products(name, description, price, image, image_data, stock) VALUES (?, ?, ?, ?, ?, ?)";
            System.out.println("SQL: " + sql);
            
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, name);
            ps.setString(2, description);
            ps.setDouble(3, price);
            ps.setString(4, imageFileName);
            ps.setBytes(5, imageData);
            ps.setInt(6, stock);

            int result = ps.executeUpdate();
            System.out.println("Rows inserted: " + result);
            
            ps.close();
            con.close();

            JOptionPane.showMessageDialog(this, 
                "✓ Product added successfully!\n\nProduct: " + name + "\nPrice: $" + price + "\nStock: " + stock + "\nImage: " + imageFileName + " (" + imageData.length + " bytes)",
                "Success", JOptionPane.INFORMATION_MESSAGE);

            clearForm();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, 
                "Please enter valid numbers for price and stock!", 
                "Invalid Input", JOptionPane.ERROR_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error reading image file: " + ex.getMessage(), 
                "Image Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, 
                "Error: " + ex.getMessage(), 
                "Database Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    private void clearForm() {
        txtName.setText("");
        txtDescription.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        selectedImageFile = null;
        lblSelectedFile.setText("Selected: None");
        lblImagePreview.setIcon(null);
        lblImagePreview.setText("No image selected");
        txtName.requestFocus();
    }

    private boolean isAdminUser() {
        return currentUser != null && "admin".equalsIgnoreCase(currentUser.getRole());
    }

    public static void main(String[] args) {
        // For testing - create a test admin user
        User testAdmin = new User(1, "admin", "password", "Admin User", "admin@test.com", "Admin Address", "admin");
        new AdminDashboard(testAdmin);
    }
}