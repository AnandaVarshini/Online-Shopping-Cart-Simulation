package com.eshop.ui;

import com.eshop.database.OrderDAO;
import com.eshop.models.Order;
import com.eshop.models.User;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AccountFrame extends JFrame {
    private final User user;
    private final OrderDAO orderDAO;
    private final DecimalFormat df = new DecimalFormat("$#,##0.00");
    private JTextArea txtUserInfo;
    private JTable ordersTable;
    private DefaultTableModel ordersModel;
    
    public AccountFrame(User user) {
        this.user = user;
        this.orderDAO = new OrderDAO();
        
        setTitle("My Account - " + user.getFullName());
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));
        
        // Header with title and refresh button
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setOpaque(false);
        
        JLabel lblTitle = new JLabel("Account Information", SwingConstants.LEFT);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 18));
        
        JButton btnRefresh = new JButton("🔄 Refresh");
        btnRefresh.setBackground(new Color(100, 150, 100));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.addActionListener(e -> refreshOrderHistory());
        
        headerPanel.add(lblTitle, BorderLayout.WEST);
        headerPanel.add(btnRefresh, BorderLayout.EAST);
        
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // User info section
        JPanel userPanel = new JPanel(new BorderLayout());
        userPanel.setBorder(BorderFactory.createTitledBorder("Profile"));
        userPanel.setBackground(Color.WHITE);
        
        txtUserInfo = new JTextArea(
            "Username: " + user.getUsername() + "\n" +
            "Full Name: " + user.getFullName() + "\n" +
            "Email: " + user.getEmail() + "\n" +
            "Address: " + user.getAddress() + "\n" +
            "Role: " + user.getRole()
        );
        txtUserInfo.setEditable(false);
        txtUserInfo.setFont(new Font("Arial", Font.PLAIN, 13));
        txtUserInfo.setLineWrap(true);
        
        userPanel.add(new JScrollPane(txtUserInfo), BorderLayout.CENTER);
        
        // Order history section
        JPanel ordersPanel = new JPanel(new BorderLayout());
        ordersPanel.setBorder(BorderFactory.createTitledBorder("Order History"));
        ordersPanel.setBackground(Color.WHITE);
        
        String[] columns = {"Order ID", "Date", "Total", "Status", "Address"};
        ordersModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        ordersTable = new JTable(ordersModel);
        ordersTable.setRowHeight(25);
        ordersTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        JScrollPane ordersScrollPane = new JScrollPane(ordersTable);
        ordersPanel.add(ordersScrollPane, BorderLayout.CENTER);
        
        // Split panel for user info and orders
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, userPanel, ordersPanel);
        splitPane.setDividerLocation(250);
        splitPane.setBackground(new Color(245, 245, 245));
        
        mainPanel.add(splitPane, BorderLayout.CENTER);
        
        add(mainPanel);
        
        // Load initial data
        loadOrderHistory();
    }
    
    private void loadOrderHistory() {
        try {
            ordersModel.setRowCount(0);
            List<Order> orders = orderDAO.getOrdersByUser(user.getId());
            
            for (Order order : orders) {
                ordersModel.addRow(new Object[]{
                    order.getId(),
                    order.getOrderDate(),
                    df.format(order.getTotalAmount()),
                    order.getStatus(),
                    order.getShippingAddress()
                });
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, 
                "Error loading orders: " + ex.getMessage(), 
                "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private void refreshOrderHistory() {
        loadOrderHistory();
        JOptionPane.showMessageDialog(this, 
            "Order history refreshed!", 
            "Refresh", JOptionPane.INFORMATION_MESSAGE);
    }
}
