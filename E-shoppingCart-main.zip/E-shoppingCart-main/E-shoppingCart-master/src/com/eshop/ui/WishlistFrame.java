package com.eshop.ui;

import com.eshop.database.PriceHistoryDAO;
import com.eshop.database.WishlistDAO;
import com.eshop.models.Product;
import com.eshop.models.User;
import java.awt.*;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;

public class WishlistFrame extends JFrame {
    private final User currentUser;
    private final WishlistDAO wishlistDAO;
    private final PriceHistoryDAO priceHistoryDAO;
    private final DecimalFormat df = new DecimalFormat("$#,##0.00");
    private final MainFrame parentFrame; // Reference to parent MainFrame for update callbacks
    
    private JPanel wishlistPanel;
    private JLabel lblWishlistCount;
    private JButton btnBack;
    
    public WishlistFrame(User user, MainFrame parent) {
        this.currentUser = user;
        this.wishlistDAO = new WishlistDAO();
        this.priceHistoryDAO = new PriceHistoryDAO();
        this.parentFrame = parent;
        
        initUI();
        loadWishlist();
    }
    
    private void initUI() {
        setTitle("My Wishlist - " + currentUser.getFullName());
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));
        mainPanel.setBackground(new Color(245, 245, 245));
        
        // Header
        mainPanel.add(createHeaderPanel(), BorderLayout.NORTH);
        
        // Wishlist items
        wishlistPanel = new JPanel();
        wishlistPanel.setLayout(new BoxLayout(wishlistPanel, BoxLayout.Y_AXIS));
        wishlistPanel.setBackground(new Color(245, 245, 245));
        
        JScrollPane scrollPane = new JScrollPane(wishlistPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
        scrollPane.setBorder(null);
        
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(70, 130, 180));
        headerPanel.setBorder(new EmptyBorder(10, 15, 10, 15));
        
        // Title with count
        JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        titlePanel.setOpaque(false);
        
        JLabel lblTitle = new JLabel("❤️ My Wishlist");
        lblTitle.setFont(new Font("Arial", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);
        
        lblWishlistCount = new JLabel("0 items");
        lblWishlistCount.setFont(new Font("Arial", Font.PLAIN, 14));
        lblWishlistCount.setForeground(Color.WHITE);
        
        titlePanel.add(lblTitle);
        titlePanel.add(lblWishlistCount);
        
        // Back and Refresh buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        buttonPanel.setOpaque(false);
        
        JButton btnRefresh = new JButton("🔄 Refresh");
        btnRefresh.setBackground(new Color(100, 150, 100));
        btnRefresh.setForeground(Color.WHITE);
        btnRefresh.setFocusPainted(false);
        btnRefresh.addActionListener(e -> loadWishlist());
        
        btnBack = new JButton("← Back");
        btnBack.setBackground(new Color(50, 90, 140));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.addActionListener(e -> dispose());
        
        buttonPanel.add(btnRefresh);
        buttonPanel.add(Box.createHorizontalStrut(5));
        buttonPanel.add(btnBack);
        
        headerPanel.add(titlePanel, BorderLayout.WEST);
        headerPanel.add(buttonPanel, BorderLayout.EAST);
        
        return headerPanel;
    }
    
    private void loadWishlist() {
        try {
            wishlistPanel.removeAll();
            
            List<Object[]> wishlistItems = wishlistDAO.getUserWishlistWithProducts(currentUser.getId());
            
            if (wishlistItems.isEmpty()) {
                JLabel lblEmpty = new JLabel("Your wishlist is empty! Start adding products.");
                lblEmpty.setFont(new Font("Arial", Font.ITALIC, 14));
                lblEmpty.setForeground(new Color(100, 100, 100));
                lblEmpty.setHorizontalAlignment(SwingConstants.CENTER);
                wishlistPanel.add(Box.createVerticalStrut(50));
                wishlistPanel.add(lblEmpty);
            } else {
                // Show price drop alerts first
                showPriceDropAlerts();
                
                // Show all wishlist items
                for (Object[] item : wishlistItems) {
                    wishlistPanel.add(createWishlistItemCard(item));
                    wishlistPanel.add(Box.createVerticalStrut(10));
                }
            }
            
            lblWishlistCount.setText(wishlistItems.size() + " item" + (wishlistItems.size() != 1 ? "s" : ""));
            wishlistPanel.add(Box.createVerticalGlue());
            wishlistPanel.revalidate();
            wishlistPanel.repaint();
        } catch (SQLException ex) {
            showError("Error loading wishlist: " + ex.getMessage());
        }
    }
    
    private void showPriceDropAlerts() {
        try {
            List<Object[]> alerts = wishlistDAO.getPriceDropAlerts(currentUser.getId(), 5); // 5% threshold
            
            if (!alerts.isEmpty()) {
                JPanel alertsPanel = new JPanel();
                alertsPanel.setLayout(new BoxLayout(alertsPanel, BoxLayout.Y_AXIS));
                alertsPanel.setBackground(new Color(255, 250, 205)); // Light yellow
                alertsPanel.setBorder(new TitledBorder("💰 Price Drop Alerts"));
                alertsPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 120));
                
                for (Object[] alert : alerts) {
                    String productName = (String) alert[2];
                    double originalPrice = (double) alert[3];
                    double currentPrice = (double) alert[4];
                    double discount = (double) alert[5];
                    
                    JLabel lblAlert = new JLabel(
                        String.format("🔔 %s: Save %s (%.1f%% off) - Now: %s", 
                            productName, df.format(originalPrice - currentPrice), discount, df.format(currentPrice))
                    );
                    lblAlert.setFont(new Font("Arial", Font.BOLD, 12));
                    lblAlert.setForeground(new Color(200, 50, 50));
                    alertsPanel.add(lblAlert);
                }
                
                wishlistPanel.add(alertsPanel);
                wishlistPanel.add(Box.createVerticalStrut(15));
            }
        } catch (SQLException ex) {
            System.err.println("Error loading price alerts: " + ex.getMessage());
        }
    }
    
    private JPanel createWishlistItemCard(Object[] item) {
        int wishlistId = (int) item[0];
        int productId = (int) item[1];
        double priceAtAdding = (double) item[2];
        String addedDate = (String) item[3];
        String productName = (String) item[4];
        double currentPrice = (double) item[5];
        String description = (String) item[6];
        int stock = (int) item[8];
        double priceDiff = (double) item[9];
        boolean notificationEnabled = (boolean) item[10];
        
        JPanel cardPanel = new JPanel(new BorderLayout(10, 10));
        cardPanel.setBackground(Color.WHITE);
        cardPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
        cardPanel.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));
        cardPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Product info
        JPanel infoPanel = new JPanel(new GridLayout(4, 1, 5, 5));
        infoPanel.setOpaque(false);
        
        JLabel lblName = new JLabel(productName);
        lblName.setFont(new Font("Arial", Font.BOLD, 14));
        
        JLabel lblAddedDate = new JLabel("Added: " + addedDate);
        lblAddedDate.setFont(new Font("Arial", Font.PLAIN, 11));
        lblAddedDate.setForeground(new Color(100, 100, 100));
        
        JLabel lblPrice = new JLabel("Original: " + df.format(priceAtAdding) + " → Current: " + df.format(currentPrice));
        lblPrice.setFont(new Font("Arial", Font.PLAIN, 12));
        
        infoPanel.add(lblName);
        infoPanel.add(lblAddedDate);
        infoPanel.add(lblPrice);
        
        // Price change indicator
        JPanel priceChangePanel = new JPanel();
        priceChangePanel.setOpaque(false);
        
        if (priceDiff < 0) {
            // Price decreased - GOOD for customer (negative price diff = savings)
            JLabel lblSaving = new JLabel("✅ PRICE DROPPED! Save " + df.format(-priceDiff));
            lblSaving.setFont(new Font("Arial", Font.BOLD, 12));
            lblSaving.setForeground(new Color(0, 128, 0)); // Green
            priceChangePanel.add(lblSaving);
        } else if (priceDiff > 0) {
            // Price increased - BAD for customer
            JLabel lblIncrease = new JLabel("⚠️ Price increased by " + df.format(priceDiff));
            lblIncrease.setFont(new Font("Arial", Font.PLAIN, 11));
            lblIncrease.setForeground(new Color(200, 50, 50)); // Red
            priceChangePanel.add(lblIncrease);
        }
        
        infoPanel.add(priceChangePanel);
        
        // Buttons
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
        buttonPanel.setOpaque(false);
        
        JButton btnToggleAlert = new JButton(notificationEnabled ? "🔔 Alerts ON" : "🔕 Alerts OFF");
        btnToggleAlert.setFont(new Font("Arial", Font.PLAIN, 11));
        btnToggleAlert.setBackground(notificationEnabled ? new Color(100, 200, 100) : new Color(200, 100, 100));
        btnToggleAlert.setForeground(Color.WHITE);
        btnToggleAlert.setFocusPainted(false);
        btnToggleAlert.addActionListener(e -> toggleNotification(wishlistId, !notificationEnabled));
        
        JButton btnAddToCart = new JButton("Add to Cart");
        btnAddToCart.setBackground(new Color(70, 130, 180));
        btnAddToCart.setForeground(Color.WHITE);
        btnAddToCart.setFocusPainted(false);
        btnAddToCart.addActionListener(e -> addToCartFromWishlist(productId, productName, currentPrice, stock));
        
        JButton btnRemove = new JButton("Remove");
        btnRemove.setBackground(new Color(200, 100, 100));
        btnRemove.setForeground(Color.WHITE);
        btnRemove.setFocusPainted(false);
        btnRemove.addActionListener(e -> removeFromWishlist(wishlistId));
        
        buttonPanel.add(btnToggleAlert);
        buttonPanel.add(btnAddToCart);
        buttonPanel.add(btnRemove);
        
        cardPanel.add(infoPanel, BorderLayout.CENTER);
        cardPanel.add(buttonPanel, BorderLayout.EAST);
        
        cardPanel.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cardPanel.setBackground(new Color(250, 250, 250));
            }
            
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cardPanel.setBackground(Color.WHITE);
            }
        });
        
        return cardPanel;
    }
    
    private void toggleNotification(int wishlistId, boolean enabled) {
        try {
            if (wishlistDAO.toggleNotification(wishlistId, enabled)) {
                showInfo("Notifications " + (enabled ? "enabled" : "disabled"));
                loadWishlist();
            }
        } catch (SQLException ex) {
            showError("Error updating notification: " + ex.getMessage());
        }
    }
    
    private void removeFromWishlist(int wishlistId) {
        try {
            if (wishlistDAO.removeFromWishlist(wishlistId)) {
                showInfo("Removed from wishlist");
                loadWishlist();
                // Notify parent MainFrame to update wishlist count
                if (parentFrame != null) {
                    parentFrame.updateWishlistCount();
                }
            }
        } catch (SQLException ex) {
            showError("Error removing from wishlist: " + ex.getMessage());
        }
    }
    
    private void addToCartFromWishlist(int productId, String productName, double currentPrice, int stock) {
        try {
            if (stock <= 0) {
                showError("This product is out of stock!");
                return;
            }
            
            // Create a Product object from the wishlist item
            Product product = new Product(productId, productName, "", currentPrice, "", stock);
            
            // Call parent MainFrame's addItemToCart method
            if (parentFrame != null) {
                parentFrame.addItemToCart(product, 1);
            } else {
                showError("Error: Cannot access shopping cart!");
            }
        } catch (Exception ex) {
            showError("Error adding to cart: " + ex.getMessage());
        }
    }
    
    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message, "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    private void showInfo(String message) {
        JOptionPane.showMessageDialog(this, message, "Info", JOptionPane.INFORMATION_MESSAGE);
    }
}
